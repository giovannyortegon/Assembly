#include<iostream>
#include"HeaderFile.h"

int main()
{
	int a = 5;
	int b = 10;
	int result = Function_a(a, b);
	PrintResult(a, b, result);

	return 0;
}