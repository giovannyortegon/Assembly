.DATA

.CODE
Function_a PROC
	add rcx, rdx
	mov rax, rcx
	ret

Function_a ENDP
END