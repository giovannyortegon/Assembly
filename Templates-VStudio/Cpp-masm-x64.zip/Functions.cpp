#include <iostream>
#include "HeaderFile.h"


void PrintResult(int a, int b, int result) {
	const char nl = '\n';
	std::cout << "------ Results ------ \n";
	std::cout <<"a = " << a << nl;
	std::cout <<"b = " << b << nl;
	std::cout << "result = " << result << nl;
}