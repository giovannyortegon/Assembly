#pragma once

extern "C" int Function_a(int a, int b);
extern void PrintResult(int a, int b, int result);