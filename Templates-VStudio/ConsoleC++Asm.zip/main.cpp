#include <cstdio>
#include <tchar.h>

extern "C" int namefunc_();

int _tmain(int argc, _TCHAR * argv[]) {

    int a = namefunc_();
    printf("a: %d\n", a);

    return (0);
}
