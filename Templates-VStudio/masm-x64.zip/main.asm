INCLUDELIB kernel32.lib

ExitProcess PROTO

.DATA

.CODE
main PROC
	
	sub rsp, 28h       ; Allocate shadow space for calling convention
	; Call ExitProcess with exit code 0
	mov rax, 0          ; Exit code 0
	call ExitProcess
main ENDP
END
